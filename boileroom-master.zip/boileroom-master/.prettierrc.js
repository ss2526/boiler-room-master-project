module.exports = {
  printWidth: 80,
  tabWidth: 2,
  semi: true,
  singleQuote: false,
  bracketSpacing: true,
  trailingComma: "es5",
  arrowParens: "always",
};
